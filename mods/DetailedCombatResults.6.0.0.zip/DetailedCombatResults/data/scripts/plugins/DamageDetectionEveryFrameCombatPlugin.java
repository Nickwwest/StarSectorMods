package data.scripts.plugins;

import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;

import data.scripts.combatanalytics.damagedetection.DamageDetector;

import java.util.List;

// Plugins have to be plain java files that are compiled by Janino.  Don't do any real work here.
public class DamageDetectionEveryFrameCombatPlugin extends BaseEveryFrameCombatPlugin {
    public DamageDetectionEveryFrameCombatPlugin(){
    }

    public void advance(float amount, List events)
    {
        DamageDetector.advance(amount);
    }

    public void init(CombatEngineAPI eng) {
        DamageDetector.init(eng);
    }
}
